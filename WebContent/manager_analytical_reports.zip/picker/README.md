Javascript Date Picker
======================

![Date picker](http://imgur.com/o2Jvt.png)


I've been fed up with all the JS calendar date pickers that are out
there - they're all too complicated, heavy, rely on frameworks that
I don't want to include, or they're ugly, or have anti-commercial
licenses, etc etc etc. So here's mine.

Please see more details at my blog here:
[http://splinter.com.au/blog/?p=278](http://splinter.com.au/blog/?p=278)
