 $(document).ready(function() 
	{ 
	 
	 
  	
  	$("#insertAssgnSubmit").click(function(){
  		  
  		document.getElementById("AssignmentDiv").style.display="block";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  	  
  
  	  }); 
  	$("#addAssgnSubmit").click(function(){
		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="block"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
 		 
 	  
 
 	  }); 
 	
  	
  	$("#insertPerfButton").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="block"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#updateAssignButton").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="block"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#updatePerformButton").click(function(){
  		  
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="block";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#insertProgressButton").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="block"; 
  		document.getElementById("intro").style.display="none";
  	  
  
  	  }); 
  	
  
  	/////
  	
  	
  	
  	
  	
  	
  	
  	
  	$("#insertAssgnSubmitMob").click(function(){
		  
  		document.getElementById("AssignmentDiv").style.display="block";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  	  
  
  	  }); 
  	$("#addAssgnSubmitMob").click(function(){
		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="block"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
 		 
 	  
 
 	  }); 
 	
  	
  	$("#insertPerfButtonMob").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="block"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#updateAssignButtonMob").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="block"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#updatePerformButtonMob").click(function(){
  		  
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="block";
  		document.getElementById("insertProgressCardDiv").style.display="none"; 
  		document.getElementById("intro").style.display="none";
  		 
  	  
  
  	  }); 
  	
  	
  	$("#insertProgressButtonMob").click(function(){
  		  
  		  
  		document.getElementById("AssignmentDiv").style.display="none";  
        document.getElementById("addAssignmentDiv").style.display="none"; 
  		document.getElementById("insertStudentPerformanceDiv").style.display="none"; 
  		document.getElementById("updateAssignmentStatusDiv").style.display="none"; 
  		document.getElementById("updateStudentPerformanceDiv").style.display="none";
  		document.getElementById("insertProgressCardDiv").style.display="block"; 
  		document.getElementById("intro").style.display="none";
  	  
  
  	  }); 
  	
  
  	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 $("#insert_assignment_form").submit(function()
	 	{
		var subject = $("#ins_subjectLists").val();
		var task = $("#ins_task").val();
		var form = $(this);
	    form.parsley().validate();
		if (form.parsley().isValid())
			{
		$.ajax({
	        url: webServerUrl,
	        data: 'request=addAssignment&subject='+subject+'&topic='+task,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Assignment Successfully Inserted..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
			}
	    });

	 
	/*Assign Assignment Form*/
	 
	 $("#add_assignment_form").submit(function()
	 	{
		var userId = $("#studentNameLists").val();
		var subject = $("#subjectLists").val();
		var topic = $("#selAssign").val();

		var form = $(this);
		 form.parsley().validate();
			if (form.parsley().isValid())
				{
		$.ajax({
	        url: webServerUrl,
	        data: 'request=assignAssignment&userId='+userId+'&subject='+subject+'&topic='+topic,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Assignment Successfully Assigned..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
				}
	    });

/*Update Assignment Form*/
	 
	 $("#update_Assign_form").submit(function()
	 	{
		var userId = $("#update_studentNameLists").val();
		var subject = $("#update_subjectLists").val();
		var status = $("#status").val();

		var form = $(this);
form.parsley().validate();
			if (form.parsley().isValid())
				{
		$.ajax({
	        url: webServerUrl,
	        data: 'request=assignmentStatusUpdation&userId='+userId+'&subject='+subject+'&status='+status,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	 
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Assignment Status Updated..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
				}
	    });

	 
	 
	 /*Insert Student Performance Form*/
	 
	 $("#insert_performance_form").submit(function()
	 	{
		var userId = $("#perform_studentNameLists").val();
		var subject = $("#perform_subjectLists").val();
		var termForPerf = $("#termForPerf").val();
		var rating = $("#insert_Ratings").val();

		var form = $(this);
		 form.parsley().validate();
			if (form.parsley().isValid())
				{
		$.ajax({
	        url: webServerUrl,
	        data: 'request=teacherRecommendation&userId='+userId+'&subject='+subject+'&rating='+rating+'&term='+termForPerf,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	 
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Student performance Report Inserted..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
				}
	    });
	 
/*Update Student Performance Form*/
	 
	 $("#student_perf_update").submit(function()
	 	{
		var userId = $("#update_perform_studentNameLists").val();
		var subjectId = $("#update_perform_subjectLists").val();
		var rating = $("#update_Ratings").val();

		var form = $(this);
		 form.parsley().validate();
			if (form.parsley().isValid())
				{
		
		$.ajax({
	        url: webServerUrl,
	        data: 'request=subjectPerformanceUpdation&userId='+userId+'&subjectId='+subjectId+'&rating='+rating,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Student performance Report Updated..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
				}
	    });

	 
/*Insert Progress Card*/
	 
	 $("#insert_Progress_Card_form").submit(function()
	 	{
		var userId = $("#insert_Progress_studentNameLists").val();
		var term = $("#term").val();
		var subject = $("#insert_Progress_subjectLists").val();
		var mark = $("#insert_Mark").val();

		var form = $(this);
		 form.parsley().validate();
			if (form.parsley().isValid())
				{
		$.ajax({
	        url: webServerUrl,
	        data: 'request=progressReports&userId='+userId+'&term='+term+'&subject='+subject+'&mark='+mark,
	        type: 'post',
	        success: function(msg) 
	        {
	             var loginJson = msg.trim();
	     		 obj = JSON.parse(loginJson);
	        	 var resultCode  = obj.response.resultcode;
	        	 var message  = obj.response.message;
	        	 
	        	 if(resultCode== 1)
	     		 {	
	        		 
	        		document.getElementById("failAlert").style.display="none"; 
	        		document.getElementById("successAlert").style.display="block";
	        		document.getElementById("customMessage").innerHTML=" Student Progress Report Inserted..";
	     		 }
	     		 else 
	     		 {
	     			document.getElementById("failAlert").style.display="block"; 
	        		document.getElementById("successAlert").style.display="none";
	              }
	          }

	     }, 200);
			return false;
				}
	    });
	 
	 
	 
	/*GetSubjects */
	 
		 $.ajax({
	         url: webServerUrl,
	         data: 'request=subjectList',
	         type: 'post',
	         success: function(msg)
	         	{
	         	 
		        	 var SubjectListResponse = msg.trim();
		        	 var obj = JSON.parse(SubjectListResponse);
		        	 var resultCode = obj.response.resultcode;
		        	 var message = obj.response.message;
		        	 var subjectsDetails = obj.response.subjectListResult.subjectsDetails;
		        	 var ins_subjectLists = document.getElementById("ins_subjectLists");
		        	 var subjectLists = document.getElementById("subjectLists");
		        	 var perform_subjectLists = document.getElementById("perform_subjectLists");
		        	 var update_perform_subjectLists = document.getElementById("update_perform_subjectLists");
		        	 var insert_Progress_subjectLists = document.getElementById("insert_Progress_subjectLists");
		        	 var update_subjectLists = document.getElementById("update_subjectLists");

	        		 ins_subjectLists.innerHTML = ins_subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';

		        	 
	        		 subjectLists.innerHTML = subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';
	        		 perform_subjectLists.innerHTML = perform_subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';
	        		 update_perform_subjectLists.innerHTML = update_perform_subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';

	        		 insert_Progress_subjectLists.innerHTML = insert_Progress_subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';
	        		 update_subjectLists.innerHTML = update_subjectLists.innerHTML + '<option value="" selected disabled>Choose Subject</option>';

		        	 for (var i=0; i<=subjectsDetails.length;i++)
		        	 {
		        		 
		        		 var cur = subjectsDetails[i];
		        		 ins_subjectLists.innerHTML = ins_subjectLists.innerHTML + '<option value="'+cur.subjectName+'">'+cur.subjectName+'</option>';
		        		 
		        		 
		        		 subjectLists.innerHTML = subjectLists.innerHTML + '<option value="'+cur.subjectName+'">'+cur.subjectName+'</option>';
		        		 
		        		 perform_subjectLists.innerHTML = perform_subjectLists.innerHTML + '<option>'+cur.subjectName+'</option>';
		        		 
		        		 update_perform_subjectLists.innerHTML = update_perform_subjectLists.innerHTML + '<option>'+cur.subjectName+'</option>';
		        		 
		        		 insert_Progress_subjectLists.innerHTML = insert_Progress_subjectLists.innerHTML + '<option>'+cur.subjectName+'</option>';
		        		 
		        		 update_subjectLists.innerHTML = update_subjectLists.innerHTML + '<option>'+cur.subjectName+'</option>';	

		        	 }
	         	}
	
	     });
		
		 



	 /*Get Class Room*/
	 $.ajax({
        url: webServerUrl,
        data: 'request=getClassRoom',
        type: 'post',
        success: function(msg)
        	{
       	 var classRoomResponse = msg.trim();
       	 
       	 var obj = JSON.parse(classRoomResponse );
       	 
       	 var resultCode = obj.response.resultcode;
       	 var message = obj.response.message;
       	 
       	  var className = obj.response.getClassRoomResult.classRoomDetails;
       	  var add_assignClassName= document.getElementById("add_assignClassName");
         	
       	 var performClassName= document.getElementById("performClassName");
       	 var update_assignClassName= document.getElementById("update_assignClassName");
       	 var update_perform_ClassName= document.getElementById("update_perform_ClassName");
       	 var insert_progress_ClassName= document.getElementById("insert_progress_ClassName");
       	
    		/*add_assignClassName.innerHTML = add_assignClassName.innerHTML + '<option value="" selected disabled>Choose Class Room</option>';

    		
       		performClassName.innerHTML = performClassName.innerHTML + '<option value="" selected disabled>Choose Class Room</option>';
            update_assignClassName.innerHTML = update_assignClassName.innerHTML + '<option value="" selected disabled>Choose Class Room</option>';

    		
    		update_perform_ClassName.innerHTML = update_perform_ClassName.innerHTML + '<option value="" selected disabled>Choose Class Room</option>';

       		insert_progress_ClassName.innerHTML = insert_progress_ClassName.innerHTML + '<option value="" selected disabled>Choose Class Room</option>';
*/
    		
       	 for (var i=0; i<=className.length;i++)
       	 {
       		 
       		 var cur = className[i];
       		 
       		 add_assignClassName.innerHTML = add_assignClassName.innerHTML + '<option >'+cur.classRoomNo+'</option>';
       		
       		 
       		 
       		 
        performClassName.innerHTML =  performClassName.innerHTML + '<option>'+cur.classRoomNo+'</option>';
       		 
       		 
       		 
        		update_assignClassName.innerHTML =  update_assignClassName.innerHTML + '<option value="'+cur.classRoomNo+'">'+cur.classRoomNo+'</option>';
       		 
       		 
       		 
       		 
       		 
       		 
       		 
       		 
       		 update_perform_ClassName.innerHTML =  update_perform_ClassName.innerHTML + '<option value="'+cur.classRoomNo+'">'+cur.classRoomNo+'</option>';

       		 
       		 
       		 
       		 insert_progress_ClassName.innerHTML =  insert_progress_ClassName.innerHTML + '<option value="'+cur.classRoomNo+'">'+cur.classRoomNo+'</option>';

       	 }
     
   
        	}
	 });
   	 

});
function assign(sel)
{
	var subject= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getAssignmentTaskList&subject='+subject,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var assigntopic = obj.response.assignmentListResult.assignmentList;
	        	 
	        	 
	        	 var selAssign = document.getElementById("selAssign");
	        	 selAssign.innerHTML ="";
	        	 for (var i=0; i<=assigntopic.length;i++)
	        	 {
	        		 
	        		 var cur = assigntopic[i];
	        		 
	        		 selAssign.innerHTML =  selAssign.innerHTML + '<option value="'+cur.assignmentTopic+'">'+cur.assignmentTopic+'</option>';
	        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}
 
function add_assignClass(sel)
 {
	var classRoomNo= sel;
	
	 
	 $.ajax({
        url: webServerUrl,
        data: 'request=getStudentNameFromClass&classRoomNo='+classRoomNo,
        type: 'post',
        success: function(msg) 
        {
        	 
       	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var studentName = obj.response.studentNameListResult.studentList;
	        	 
	        	 
	        	 var studentNameLists = document.getElementById("studentNameLists");
	        	 
	        	studentNameLists.innerHTML ="";
	        	studentNameLists.innerHTML ='<option disabled selected>Select Student</option>';
	        	 for (var i=0; i<=studentName.length;i++)
	        	 {
	        		 
	        		 var cur = studentName[i];
	        		 
	        		 studentNameLists.innerHTML =  studentNameLists.innerHTML + '<option value="'+cur.studentId+'">'+cur.studentId+'</option>';
	        		 
	        	 }
	    
       	 

        }

    });
	
	 
	 
	
 }
function up_assign(sel)
{
	var subject= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getAssignmentTaskList&subject='+subject,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var assigntopic = obj.response.assignmentListResult.assignmentList;
	        	 
	        	 
	        	 var update_assignment = document.getElementById("update_assignment");
	        	 update_assignment.innerHTML ="";
	        	 update_assignment.innerHTML =' <option disabled selected>Select Student</option>';
	        	
	        	 for (var i=0; i<=assigntopic.length;i++)
	        	 {
	        		 
	        		 var cur = assigntopic[i];
	        		 
	        		 update_assignment.innerHTML =  update_assignment.innerHTML + '<option value="'+cur.assignmentTopic+'">'+cur.assignmentTopic+'</option>';
	        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}
 
function performClass(sel)
{
	var classRoomNo= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getStudentNameFromClass&classRoomNo='+classRoomNo,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var studentName = obj.response.studentNameListResult.studentList;
	        	 
	        	 
	        	  var perform_studentNameLists = document.getElementById("perform_studentNameLists");
	        	  perform_studentNameLists.innerHTML ="";
	        	  perform_studentNameLists.innerHTML ='<option disabled selected>Select Student</option>';
	        	  
	        	  
	        	 for (var i=0; i<=studentName.length;i++)
	        	 {
	        		 
	        		 var cur = studentName[i];
	        		 
	        		 perform_studentNameLists.innerHTML =  perform_studentNameLists.innerHTML + '<option>'+cur.studentId+'</option>';
	        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}
function update_assignClass(sel)
{
	var classRoomNo= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getStudentNameFromClass&classRoomNo='+classRoomNo,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var studentName = obj.response.studentNameListResult.studentList;
	        	 
	        	 
	        	  var update_studentNameLists = document.getElementById("update_studentNameLists");	       
	        	  update_studentNameLists.innerHTML ="";
	        	  update_studentNameLists.innerHTML ='<option disabled selected>Select Student</option>';
	        	  
	        	  
	        	 for (var i=0; i<=studentName.length;i++)
	        	 {
	        		 
	        		 var cur = studentName[i];
	        		 
	        		 update_studentNameLists.innerHTML =  update_studentNameLists.innerHTML + '<option>'+cur.studentId+'</option>';	        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}

function update_perform_Class(sel)
{
	
	
	
	var classRoomNo= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getStudentNameFromClass&classRoomNo='+classRoomNo,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var studentName = obj.response.studentNameListResult.studentList;
	        	 
	        	 
	        	  var update_perform_studentNameLists = document.getElementById("update_perform_studentNameLists");	    
	        	  update_perform_studentNameLists.innerHTML ="";
	        	  update_perform_studentNameLists.innerHTML =' <option disabled selected>Select Student</option>';
	        	 
	        	 for (var i=0; i<=studentName.length;i++)
	        	 {
	        		 
	        		 var cur = studentName[i];
	        		 
	        		 update_perform_studentNameLists.innerHTML =  update_perform_studentNameLists.innerHTML + '<option>'+cur.studentId+'</option>';        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}


function insert_progress_Class(sel)
{
	
	
	
	
	
/*	
	
	document.getElementById("InsProgressSelect").style.display="block";
	

	*/
	
	var classRoomNo= sel;
	
	 
	 $.ajax({
       url: webServerUrl,
       data: 'request=getStudentNameFromClass&classRoomNo='+classRoomNo,
       type: 'post',
       success: function(msg) 
       {
       	 
      	 	 var StudentNameResponse = msg.trim();
	        	 
	        	 var obj = JSON.parse(StudentNameResponse);
	        	 
	        	 var resultCode = obj.response.resultcode;
	        	 var message = obj.response.message;
	        	 
	        	  var studentName = obj.response.studentNameListResult.studentList;
	        	 
	        	 
	        	  var insert_Progress_studentNameLists = document.getElementById("insert_Progress_studentNameLists");     
	        	  insert_Progress_studentNameLists.innerHTML ="";
	        	  insert_Progress_studentNameLists.innerHTML = '<option disabled selected>Select Student</option>';	 
	        	 for (var i=0; i<=studentName.length;i++)
	        	 {
	        		 
	        		 var cur = studentName[i];
	        		 
	        		 insert_Progress_studentNameLists.innerHTML =  insert_Progress_studentNameLists.innerHTML + '<option>'+cur.studentId+'</option>';	        		 
	        	 }
	    
      	 

       }

   });
	
	 
	 
	
}


